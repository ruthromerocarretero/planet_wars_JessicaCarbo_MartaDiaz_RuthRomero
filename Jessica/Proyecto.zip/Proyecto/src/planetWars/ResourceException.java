package planetWars;

public class ResourceException extends Exception {

    public ResourceException(String message) {
        super(message);  
        
    }
}